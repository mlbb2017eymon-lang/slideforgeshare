"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { motion } from "framer-motion";
import LandingNav from "@/components/landing/LandingNav";
import Starfield from "@/components/landing/Starfield";
import CrystalHero from "@/components/landing/CrystalHero";

const STEPS = [
  {
    number: "01",
    title: "Describe",
    body: "Tell SlideForge what the presentation is for, in a sentence or two.",
  },
  {
    number: "02",
    title: "Generate",
    body: "AI writes the narrative, lays out six slides, and creates matching visuals.",
  },
  {
    number: "03",
    title: "Edit & export",
    body: "Fine-tune any slide in the editor, then export straight to PowerPoint.",
  },
];

const FEATURES = [
  {
    icon: "✎",
    title: "AI Storytelling",
    body: "Turns your idea into a structured, compelling narrative before it designs a slide.",
  },
  {
    icon: "◈",
    title: "AI Visuals",
    body: "Generates relevant images and graphics that bring your ideas to life.",
  },
  {
    icon: "✦",
    title: "Smart Editor",
    body: "Easily customize any slide with a modern, intuitive editor underneath.",
  },
  {
    icon: "↗",
    title: "Export Anywhere",
    body: "Download in high quality or share online with a single click.",
  },
];

const heroContainer = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
};

const heroItem = {
  hidden: { opacity: 0, y: 14 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function LandingPage() {
  const router = useRouter();
  const supabase = createClient();
  const [prompt, setPrompt] = useState("");

  async function handleStart(e: React.FormEvent) {
    e.preventDefault();

    const params = new URLSearchParams();
    if (prompt.trim()) params.set("prompt", prompt.trim());

    const query = params.toString();

    const destination = `/workspace${query ? `?${query}` : ""}`;
    const { data: { user } } = await supabase.auth.getUser();
    router.push(user ? destination : `/login?next=${encodeURIComponent(destination)}`);
  }

  return (
    <main className="relative min-h-screen overflow-x-clip bg-[#010613] text-white">
      <LandingNav />

      {/* HERO */}
      <section className="relative overflow-hidden pb-16 pt-[150px] text-center">
        <div className="nebula" />
        <div className="grid-floor" />
        <Starfield />
        <div className="grain" />

        <motion.div
          variants={heroContainer}
          initial="hidden"
          animate="show"
          className="relative mx-auto max-w-6xl px-5 sm:px-6"
        >
          <motion.span
            variants={heroItem}
            className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-xs text-white/50"
          >
            ✦ AI Presentation Generator
          </motion.span>

          <motion.h1
            variants={heroItem}
            className="mx-auto mt-5 max-w-2xl text-[clamp(34px,6vw,58px)] font-extrabold leading-[1.08] tracking-[-0.025em]"
          >
            Your ideas. Beautiful slides.
            <br />
            <span className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
              Powered by AI.
            </span>
          </motion.h1>

          <motion.p
            variants={heroItem}
            className="mx-auto mt-4 max-w-md text-[15px] leading-7 text-white/50"
          >
            Describe what you&apos;re presenting. SlideForge writes the
            story, designs every slide, and generates the visuals — no
            design skills needed.
          </motion.p>

          <motion.div variants={heroItem} className="mt-3">
            <CrystalHero />
          </motion.div>

          <motion.form
            variants={heroItem}
            onSubmit={handleStart}
            className="mx-auto mt-2 flex max-w-xl items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] py-2 pl-[18px] pr-2 backdrop-blur-xl"
          >
            <span className="shrink-0 text-accent">✦</span>
            <input
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your presentation idea..."
              className="min-w-0 flex-1 bg-transparent py-2.5 text-sm text-white outline-none placeholder:text-white/25"
            />
            <button
              type="submit"
              className="shrink-0 rounded-full bg-gradient-to-br from-primary to-accent px-5 py-2.5 text-[13px] font-semibold text-white transition hover:brightness-110"
            >
              Generate →
            </button>
          </motion.form>

          <motion.div
            variants={heroItem}
            className="mt-3.5 flex flex-wrap justify-center gap-2"
          >
            {["10 slides", "Modern", "16:9"].map((chip) => (
              <span
                key={chip}
                className="rounded-full border border-white/10 px-3 py-1 text-[11px] text-white/45"
              >
                {chip}
              </span>
            ))}
          </motion.div>

          <motion.p
            variants={heroItem}
            className="mx-auto mt-3.5 max-w-lg text-xs text-white/25"
          >
            Try: &ldquo;Marketing strategy for a tech startup&rdquo; &middot;
            &ldquo;History of space exploration&rdquo; &middot; &ldquo;Business
            plan for 2025&rdquo;
          </motion.p>
        </motion.div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="border-t border-white/10 bg-white/[0.015]">
        <div className="mx-auto max-w-6xl px-5 py-20 sm:px-6">
          <h2 className="text-2xl font-semibold tracking-tight text-white sm:text-3xl">
            From prompt to presentation, in three steps
          </h2>

          <div className="mt-10 grid gap-8 sm:grid-cols-3">
            {STEPS.map((step) => (
              <div key={step.number}>
                <span className="font-[family-name:var(--font-geist-mono)] text-xs text-accent">
                  {step.number}
                </span>
                <h3 className="mt-3 text-base font-semibold text-white">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-6 text-white/45">
                  {step.body}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="mx-auto max-w-6xl px-5 py-20 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((feature) => (
            <div
              key={feature.title}
              className="rounded-2xl border border-white/8 bg-white/[0.02] p-6"
            >
              <div className="flex h-[34px] w-[34px] items-center justify-center rounded-[9px] bg-gradient-to-br from-primary/25 to-accent/20 text-base text-accent">
                {feature.icon}
              </div>
              <h3 className="mt-4 text-sm font-semibold text-white">
                {feature.title}
              </h3>
              <p className="mt-2 text-[13px] leading-6 text-white/40">
                {feature.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA BAND */}
      <section className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-5 py-16 sm:flex-row sm:items-center sm:px-6">
          <div>
            <h2 className="text-xl font-semibold text-white sm:text-2xl">
              Your next presentation is just a prompt away
            </h2>
            <p className="mt-2 text-sm text-white/40">
              Start free — no card, no setup.
            </p>
          </div>

          <a
            href="/login?next=/workspace"
            className="shrink-0 rounded-full bg-gradient-to-br from-primary to-accent px-6 py-3.5 text-sm font-semibold text-white transition hover:brightness-110"
          >
            Get started →
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/10">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-xs text-white/25 sm:flex-row sm:px-6">
          <span>© {new Date().getFullYear()} SlideForge</span>
          <span>Built for people who hate making slides</span>
        </div>
      </footer>
    </main>
  );
}
