import { NextResponse } from "next/server";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const MODEL = "openai/gpt-oss-120b";
const clean=(v:unknown,n:number)=>String(v??"").replace(/\s+/g," ").trim().slice(0,n);
export async function POST(request:Request){
 try{
  const key=process.env.GROQ_API_KEY;if(!key)return NextResponse.json({error:"GROQ_API_KEY is missing"},{status:500});
  const body=await request.json();const instruction=clean(body?.instruction,2000);const slide=body?.slide;
  if(!instruction||!slide)return NextResponse.json({error:"instruction and slide are required"},{status:400});
  const system=`You are SlideForge AI Assistant. Modify the provided structured slide according to the user's instruction. Return JSON only with one key: slide. Preserve the existing schema and element IDs when possible. You may rewrite text, add/remove/rearrange elements, change layout, improve composition, or change image prompts. Never invent statistics or factual claims. If asked for a chart but no numeric data exists, use a process/cards/diagram instead. Keep x,y,width,height between 0 and 100, max 8 elements, and avoid overlapping elements. Slide schema includes title,subtitle,bullets,visual,layout,purpose,elements,speakerNotes. Element types: text,image,chart,table,diagram,stat,timeline,quote,cards,comparison,process,roadmap,shape.`;
  const r=await fetch("https://api.groq.com/openai/v1/chat/completions",{method:"POST",headers:{Authorization:`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model:MODEL,temperature:.35,max_completion_tokens:9000,messages:[{role:"system",content:system},{role:"user",content:`Instruction:\n${instruction}\n\nCurrent slide JSON:\n${JSON.stringify(slide)}`}],response_format:{type:"json_object"}})});
  const data=await r.json();if(!r.ok)return NextResponse.json({error:data?.error?.message||"Groq edit failed"},{status:r.status});
  const content=data?.choices?.[0]?.message?.content;let parsed:any;try{parsed=JSON.parse(content)}catch{return NextResponse.json({error:"Groq returned invalid JSON"},{status:422})}
  if(!parsed?.slide)return NextResponse.json({error:"AI returned no slide"},{status:422});
  return NextResponse.json({success:true,slide:parsed.slide});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"AI edit failed"},{status:500})}
}
