import { NextResponse } from "next/server";
import { STYLE_PRESETS } from "@/lib/presentation/styles";
import { PRESENTATION_TYPES, chooseElementTypes, chooseLayout, findStylePreset, normalizeLayout } from "@/lib/presentation/engine";
import type { ChartKind, DiagramKind, Presentation, PresentationElementType, SlideElement, SlideSpec } from "@/lib/presentation/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const GROQ_MODEL = "openai/gpt-oss-120b";
const ALLOWED_SLIDE_COUNTS = [5, 6, 8, 10, 12] as const;

type GenerateBody = { prompt?: unknown; language?: unknown; style?: unknown; slideCount?: unknown; presentationType?: unknown };

function clean(value: unknown, max: number) {
  return String(value ?? "").replace(/\s+/g, " ").trim().slice(0, max);
}
function num(value: unknown, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : fallback;
}
function id(prefix: string, index: number) { return `${prefix}-${index + 1}-${Math.random().toString(36).slice(2, 7)}`; }
function clampArray<T>(value: unknown, max: number): T[] { return Array.isArray(value) ? value.slice(0, max) as T[] : []; }

function normalizeElement(raw: any, index: number, allowCharts: boolean): SlideElement | null {
  const type = clean(raw?.type, 30) as PresentationElementType;
  const frame = { id: clean(raw?.id, 80) || id("el", index), x: num(raw?.x), y: num(raw?.y), width: Math.max(8, num(raw?.width, 30)), height: Math.max(6, num(raw?.height, 20)) };
  if (type === "text") return { ...frame, type, text: clean(raw?.text, 800), role: ["heading","body","label"].includes(raw?.role) ? raw.role : "body" };
  if (type === "image") return { ...frame, type, prompt: clean(raw?.prompt || raw?.visual, 1200), src: typeof raw?.src === "string" ? raw.src : undefined, fit: raw?.fit === "contain" ? "contain" : "cover" };
  if (type === "chart" && allowCharts) {
    const kind: ChartKind = ["bar","line","area","donut","pie","radar","scatter"].includes(raw?.kind) ? raw.kind : "bar";
    const labels = clampArray<string>(raw?.labels, 8).map(v => clean(v, 30));
    const values = clampArray<number>(raw?.values, 8).map(v => Number(v)).filter(Number.isFinite).map(v => Math.max(0, v));
    if (!labels.length || labels.length !== values.length) return null;
    return { ...frame, type, kind, title: clean(raw?.title, 100) || undefined, labels, values, unit: clean(raw?.unit, 20) || undefined };
  }
  if (type === "table") {
    const columns = clampArray<string>(raw?.columns, 6).map(v => clean(v, 40));
    const rows = clampArray<string[]>(raw?.rows, 8).map(row => clampArray<string>(row, columns.length || 5).map(v => clean(v, 80)));
    if (!columns.length || !rows.length) return null;
    return { ...frame, type, columns, rows };
  }
  if (type === "diagram") {
    const kind: DiagramKind = ["flow","cycle","funnel","pyramid","matrix","swot","org"].includes(raw?.kind) ? raw.kind : "flow";
    const nodes = clampArray<any>(raw?.nodes, 8).map((n, i) => ({ id: clean(n?.id, 30) || `n${i+1}`, label: clean(n?.label, 80), description: clean(n?.description, 120) || undefined })).filter(n => n.label);
    const ids = new Set(nodes.map(n => n.id));
    const edges = clampArray<any>(raw?.edges, 12).map(e => ({ from: clean(e?.from, 30), to: clean(e?.to, 30) })).filter(e => ids.has(e.from) && ids.has(e.to));
    if (!nodes.length) return null;
    return { ...frame, type, kind, title: clean(raw?.title, 100) || undefined, nodes, edges };
  }
  if (type === "stat") return { ...frame, type, value: clean(raw?.value, 40), label: clean(raw?.label, 100), change: clean(raw?.change, 50) || undefined };
  if (type === "timeline") return { ...frame, type, items: clampArray<any>(raw?.items, 8).map(i => ({ date: clean(i?.date, 30), title: clean(i?.title, 80), description: clean(i?.description, 120) || undefined })).filter(i => i.title) };
  if (type === "quote") return { ...frame, type, quote: clean(raw?.quote, 400), author: clean(raw?.author, 80) || undefined, source: clean(raw?.source, 100) || undefined };
  if (type === "cards") return { ...frame, type, items: clampArray<any>(raw?.items, 5).map(i => ({ title: clean(i?.title, 70), body: clean(i?.body, 160), icon: clean(i?.icon, 10) || undefined })).filter(i => i.title) };
  if (type === "comparison") return { ...frame, type, leftTitle: clean(raw?.leftTitle, 70), rightTitle: clean(raw?.rightTitle, 70), rows: clampArray<any>(raw?.rows, 7).map(r => ({ label: clean(r?.label, 60), left: clean(r?.left, 100), right: clean(r?.right, 100) })).filter(r => r.label) };
  if (type === "process") return { ...frame, type, steps: clampArray<any>(raw?.steps, 6).map(s => ({ title: clean(s?.title, 70), description: clean(s?.description, 120) || undefined })).filter(s => s.title) };
  if (type === "roadmap") return { ...frame, type, phases: clampArray<any>(raw?.phases, 5).map(p => ({ title: clean(p?.title, 70), timeframe: clean(p?.timeframe, 40) || undefined, items: clampArray<string>(p?.items, 5).map(v => clean(v, 100)) })).filter(p => p.title) };
  if (type === "shape") return { ...frame, type, shape: ["card","circle","line"].includes(raw?.shape) ? raw.shape : "card" };
  return null;
}

function fallbackElements(slide: any, index: number, allowCharts: boolean): SlideElement[] {
  const elements: SlideElement[] = [];
  const title = clean(slide?.title, 100);
  const subtitle = clean(slide?.subtitle, 160);
  if (title) elements.push({ id: `title-${index}`, type: "text", x: 7, y: 7, width: 78, height: 12, text: title, role: "heading" });
  if (subtitle) elements.push({ id: `subtitle-${index}`, type: "text", x: 7, y: 19, width: 70, height: 8, text: subtitle, role: "label" });
  const bullets = clampArray<string>(slide?.bullets, 4).map(v => clean(v, 180)).filter(Boolean);
  if (bullets.length) elements.push({ id: `body-${index}`, type: "cards", x: 7, y: 32, width: 48, height: 48, items: bullets.map((b, i) => ({ title: `Point ${i+1}`, body: b })) });
  const visual = clean(slide?.visual, 1000);
  if (visual) elements.push({ id: `image-${index}`, type: "image", x: 59, y: 28, width: 34, height: 55, prompt: visual, fit: "cover" });
  return elements.slice(0, 8);
}

function normalizeSlide(raw: any, index: number, style: ReturnType<typeof findStylePreset>, presentationType: string, allowCharts: boolean): SlideSpec {
  const bullets = clampArray<string>(raw?.bullets, 6).map(v => clean(v, 180)).filter(Boolean).slice(0, 4);
  const purpose = clean(raw?.purpose, 180) || `Explain the key idea of slide ${index + 1}`;
  const rawElements = clampArray<any>(raw?.elements, 10).map((el, i) => normalizeElement(el, i, allowCharts)).filter(Boolean) as SlideElement[];
  const elements = rawElements.length ? rawElements : fallbackElements(raw, index, allowCharts);
  return {
    title: clean(raw?.title, 100) || `Slide ${index + 1}`,
    subtitle: clean(raw?.subtitle, 180),
    bullets,
    visual: clean(raw?.visual, 1000),
    purpose,
    layout: normalizeLayout(raw?.layout, chooseLayout(purpose, style.preferredLayouts)),
    elements,
    speakerNotes: clean(raw?.speakerNotes, 1200) || undefined,
  };
}

export async function POST(request: Request) {
  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) return NextResponse.json({ error: "GROQ_API_KEY is missing" }, { status: 500 });
    const body = (await request.json()) as GenerateBody;
    const prompt = clean(body.prompt, 5000);
    if (!prompt) return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    const language = clean(body.language, 80) || "English";
    const requestedStyle = clean(body.style, 100) || "minimal-core";
    const style = findStylePreset(requestedStyle, STYLE_PRESETS);
    const presentationType = clean(body.presentationType, 50) || "auto";
    const requestedCount = Number(body.slideCount);
    const slideCount = (ALLOWED_SLIDE_COUNTS as readonly number[]).includes(requestedCount) ? requestedCount : 6;
    const type = PRESENTATION_TYPES.find(t => t.id === presentationType) ?? PRESENTATION_TYPES[0];
    const tags = ["business","finance","technology","ai","science","medical","education","marketing","startup","history","product"].filter(tag => prompt.toLowerCase().includes(tag));
    const preferred = chooseElementTypes(type.id, tags, style);
    const allowCharts = /\d|percent|%|revenue|sales|growth|rate|statistics|statistic|данн|процент|выруч|продаж|рост|статист/i.test(prompt);

    const systemPrompt = `You are SlideForge's presentation planner. Return JSON only. Build a coherent ${slideCount}-slide presentation in ${language}. Style: ${style.name}. Presentation type: ${type.name}.
The presentation must be information-rich, visually varied and editable. Do NOT make every slide a title plus four bullets.
Possible elements: text, image, chart, table, diagram, stat, timeline, quote, cards, comparison, process, roadmap, shape.
Preferred element types: ${preferred.join(", ")}.
Use 0-3 image elements per slide depending on the story. Use charts only when the user supplied quantitative data or the topic clearly contains explicit numeric data; never invent statistics. Tables must contain information supported by the prompt or common structural comparisons, not fabricated measurements.
Every image prompt must describe a visual scene and must forbid text, logos, UI, charts and watermarks inside the image.
Layouts should vary naturally: hero, focus, split, image-left, image-right, grid, dashboard, timeline, comparison, quote, minimal, data, closing, process, roadmap.
Each element uses x,y,width,height in percentages 0-100. Keep elements inside the slide, avoid overlaps, and use max 8 elements per slide.
Return {title,description,topic,presentationType,styleId,slides:[...]}. Each slide needs title,subtitle,purpose,layout,bullets,visual,elements,speakerNotes.\n`;
    const userPrompt = `Topic: ${prompt}\nLanguage: ${language}\nStyle: ${style.name}\nSlide count: ${slideCount}\nPresentation type: ${type.name}\nCharts allowed: ${allowCharts}\n`;

    let parsed: any = null;
    let lastError = "Groq returned an invalid presentation.";
    for (let attempt = 0; attempt < 2; attempt++) {
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model: GROQ_MODEL, temperature: 0.55, max_completion_tokens: 18000, messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }], response_format: { type: "json_object" } }),
      });
      const data = await response.json();
      if (!response.ok) return NextResponse.json({ error: data?.error?.message || "Groq generation failed" }, { status: response.status });
      const content = data?.choices?.[0]?.message?.content;
      try { parsed = JSON.parse(content); } catch { lastError = "Groq returned invalid JSON."; continue; }
      if (Array.isArray(parsed?.slides) && parsed.slides.length >= slideCount) break;
      lastError = `Groq returned fewer than ${slideCount} slides.`;
    }
    if (!parsed?.slides || !Array.isArray(parsed.slides)) return NextResponse.json({ error: lastError }, { status: 422 });

    const slides = parsed.slides.slice(0, slideCount).map((slide: any, i: number) => normalizeSlide(slide, i, style, type.id, allowCharts));
    while (slides.length < slideCount) slides.push(normalizeSlide({ title: `Slide ${slides.length + 1}`, subtitle: "", bullets: [], visual: "", purpose: "Closing takeaway" }, slides.length, style, type.id, allowCharts));
    const result: Presentation = { title: clean(parsed.title, 140) || "Untitled Presentation", description: clean(parsed.description, 500), topic: clean(parsed.topic, 300) || prompt, language, styleId: style.id, presentationType: type.id, slides };
    return NextResponse.json({ success: true, ...result, slideCount: slides.length, styleName: style.name });
  } catch (error) {
    console.error("Generation error:", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Failed to generate presentation" }, { status: 500 });
  }
}
